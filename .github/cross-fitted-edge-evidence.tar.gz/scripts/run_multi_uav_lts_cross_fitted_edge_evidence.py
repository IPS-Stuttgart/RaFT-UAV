#!/usr/bin/env python3
"""Run leakage-safe out-of-fold evidence for learned LTS association edges."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import run_multi_uav_lts_improved_evidence as improved
import run_multi_uav_lts_public_evidence as evidence
from raft_uav.multi_uav_lts.fixed_population_cv import build_stratified_folds

FOLD_COUNT = 5
FOLD_SEED = 0
_EDGE_MODEL_TOKEN = "{EDGE_MODEL_JSON}"

_DELAYED_TRANSLATION_ARGUMENTS = (
    "--enable-delayed-path-cover",
    "--delayed-max-gap",
    "0",
    "--delayed-lookahead-frames",
    "2",
    "--delayed-successors-per-frame",
    "3",
    "--delayed-continuation-weight",
    "0.75",
    "--enable-common-motion",
    "--common-motion-min-pairs",
    "4",
    "--common-motion-max-normalized-step",
    "8.0",
    "--common-motion-max-normalized-residual",
    "1.5",
)
_SIMILARITY_ARGUMENTS = (
    "--common-motion-model",
    "similarity",
    "--similarity-min-pairs",
    "4",
    "--similarity-max-scale-change",
    "0.12",
    "--similarity-max-rotation-deg",
    "10.0",
    "--similarity-max-normalized-residual",
    "1.0",
    "--similarity-min-normalized-spread",
    "2.0",
    "--similarity-min-residual-improvement",
    "0.05",
)
_SWARM_ARGUMENTS = (
    "--swarm-relative-weight",
    "0.75",
    "--swarm-relative-clip",
    "4.0",
    "--swarm-neighbors",
    "4",
    "--swarm-radius-scale",
    "12.0",
)
_EDGE_ARGUMENTS = (
    "--edge-model-json",
    _EDGE_MODEL_TOKEN,
    "--edge-model-weight",
    "1.0",
    "--edge-model-clip",
    "4.0",
)
_BEAM_ARGUMENTS = (
    "--enable-ambiguity-beam",
    "--ambiguity-beam-width",
    "8",
    "--ambiguity-beam-max-component-nodes",
    "16",
    "--ambiguity-beam-margin",
    "1.0",
)

STATIC_CANDIDATES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("graph_delayed_translation", _DELAYED_TRANSLATION_ARGUMENTS),
    (
        "graph_delayed_similarity",
        (*_DELAYED_TRANSLATION_ARGUMENTS, *_SIMILARITY_ARGUMENTS),
    ),
    (
        "graph_delayed_swarm",
        (*_DELAYED_TRANSLATION_ARGUMENTS, *_SWARM_ARGUMENTS),
    ),
)

CROSS_FITTED_CANDIDATES: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "graph_edge_oof",
        (*_DELAYED_TRANSLATION_ARGUMENTS, *_EDGE_ARGUMENTS),
    ),
    (
        "graph_edge_swarm_oof",
        (*_DELAYED_TRANSLATION_ARGUMENTS, *_EDGE_ARGUMENTS, *_SWARM_ARGUMENTS),
    ),
    (
        "graph_edge_swarm_beam_oof",
        (
            *_DELAYED_TRANSLATION_ARGUMENTS,
            *_EDGE_ARGUMENTS,
            *_SWARM_ARGUMENTS,
            *_BEAM_ARGUMENTS,
        ),
    ),
)

_EDGE_MODEL_FIT_ARGUMENTS = (
    "--min-proposal-confidence",
    "0.003",
    "--duplicate-iou",
    "0.95",
    "--min-truth-iou",
    "0.3",
    "--max-gap",
    "0",
    "--max-link-cost",
    "2.25",
    "--negative-candidates-per-left",
    "5",
    "--enable-common-motion",
    "--common-motion-min-pairs",
    "4",
    "--common-motion-max-normalized-step",
    "8.0",
    "--common-motion-max-normalized-residual",
    "1.5",
    "--swarm-neighbors",
    "4",
    "--swarm-radius-scale",
    "12.0",
    "--swarm-unmatched-penalty",
    "2.0",
    "--l2-penalty",
    "1.0",
    "--max-iterations",
    "500",
)


@dataclass(frozen=True)
class FoldDefinition:
    index: int
    training_sequences: tuple[str, ...]
    heldout_sequences: tuple[str, ...]


@dataclass(frozen=True)
class FoldModel:
    fold: FoldDefinition
    model_path: Path
    summary_path: Path
    model_sha256: str
    training_examples: int
    positive_candidate_edges: int
    negative_candidate_edges: int


def _dataset_path_from_inputs(arguments: Sequence[str], field: str) -> Path:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--inputs-json", type=Path, required=True)
    parsed, _unknown = parser.parse_known_args(arguments)
    payload_path = parsed.inputs_json.expanduser().resolve()
    payload = json.loads(payload_path.read_text(encoding="utf-8"))
    try:
        raw_path = payload["dataset"][field]
    except (KeyError, TypeError) as exc:
        raise ValueError(f"{payload_path}: missing dataset.{field}") from exc
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError(f"{payload_path}: invalid dataset.{field}")
    path = Path(raw_path).expanduser().resolve()
    if not path.is_dir():
        raise FileNotFoundError(f"dataset.{field} is not a directory: {path}")
    return path


def _sequence_manifest(seed_dir: Path, *, expected_sequences: int) -> tuple[str, ...]:
    sequences = tuple(sorted(path.stem for path in seed_dir.glob("*.txt")))
    if len(sequences) != expected_sequences:
        raise ValueError(
            f"seed manifest covers {len(sequences)} sequences, "
            f"expected {expected_sequences}"
        )
    if len(set(sequences)) != len(sequences):
        raise ValueError("seed manifest contains duplicate sequence names")
    return sequences


def _build_fold_definitions(
    sequences: tuple[str, ...],
    *,
    fold_count: int = FOLD_COUNT,
    seed: int = FOLD_SEED,
) -> tuple[FoldDefinition, ...]:
    folds = build_stratified_folds(sequences, fold_count=fold_count, seed=seed)
    all_sequences = set(sequences)
    seen: set[str] = set()
    definitions: list[FoldDefinition] = []
    for index, heldout in enumerate(folds):
        heldout_set = set(heldout)
        training = tuple(sequence for sequence in sequences if sequence not in heldout_set)
        if not heldout or not training:
            raise ValueError(f"fold {index} has an empty training or held-out partition")
        if heldout_set & set(training):
            raise ValueError(f"fold {index} leaks held-out sequences into training")
        duplicates = seen & heldout_set
        if duplicates:
            raise ValueError(
                f"held-out sequences occur in multiple folds: {', '.join(sorted(duplicates))}"
            )
        seen.update(heldout_set)
        definitions.append(
            FoldDefinition(
                index=index,
                training_sequences=training,
                heldout_sequences=tuple(heldout),
            )
        )
    if seen != all_sequences:
        missing = sorted(all_sequences - seen)
        extra = sorted(seen - all_sequences)
        raise ValueError(f"fold manifest mismatch: missing={missing}, extra={extra}")
    return tuple(definitions)


def _replace_edge_model_token(
    arguments: Sequence[str],
    model_path: Path,
) -> tuple[str, ...]:
    count = sum(token == _EDGE_MODEL_TOKEN for token in arguments)
    if count != 1:
        raise ValueError(
            f"cross-fitted candidate must contain exactly one {_EDGE_MODEL_TOKEN!r} token"
        )
    return tuple(str(model_path) if token == _EDGE_MODEL_TOKEN else token for token in arguments)


def _sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def _load_json_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected a JSON object in {path}")
    return payload


def _validate_model_provenance(
    model_path: Path,
    summary_path: Path,
    fold: FoldDefinition,
) -> FoldModel:
    model = _load_json_object(model_path)
    summary = _load_json_object(summary_path)
    expected = list(fold.training_sequences)
    heldout = set(fold.heldout_sequences)

    if model.get("schema") != "raft-uav-multi-uav-lts-edge-likelihood-v1":
        raise ValueError(f"fold {fold.index} has an unsupported edge-model schema")
    if summary.get("schema") != "raft-uav-multi-uav-lts-edge-model-fit-summary-v1":
        raise ValueError(f"fold {fold.index} has an unsupported fit-summary schema")
    summary_sequences = summary.get("selected_sequences")
    metadata = model.get("metadata")
    model_sequences = metadata.get("selected_sequences") if isinstance(metadata, dict) else None
    if summary_sequences != expected or model_sequences != expected:
        raise ValueError(
            f"fold {fold.index} edge-model provenance does not match its training split"
        )
    if heldout & set(str(value) for value in summary_sequences):
        raise ValueError(f"fold {fold.index} edge model contains held-out sequences")
    if model.get("sequence_count") != len(fold.training_sequences):
        raise ValueError(f"fold {fold.index} edge-model sequence count is inconsistent")
    if summary.get("selected_sequence_count") != len(fold.training_sequences):
        raise ValueError(f"fold {fold.index} fit-summary sequence count is inconsistent")

    training_examples = summary.get("training_examples")
    positive_edges = summary.get("positive_candidate_edges")
    negative_edges = summary.get("negative_candidate_edges")
    for name, value in (
        ("training_examples", training_examples),
        ("positive_candidate_edges", positive_edges),
        ("negative_candidate_edges", negative_edges),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"fold {fold.index} has invalid {name}: {value!r}")
    if training_examples != positive_edges + negative_edges:
        raise ValueError(f"fold {fold.index} fit-summary edge counts are inconsistent")
    if (
        model.get("training_example_count") != training_examples
        or model.get("positive_example_count") != positive_edges
        or model.get("negative_example_count") != negative_edges
    ):
        raise ValueError(f"fold {fold.index} model and fit-summary counts differ")
    return FoldModel(
        fold=fold,
        model_path=model_path,
        summary_path=summary_path,
        model_sha256=_sha256(model_path),
        training_examples=training_examples,
        positive_candidate_edges=positive_edges,
        negative_candidate_edges=negative_edges,
    )


def _fit_fold_models(
    proposal_dir: Path,
    truth_dir: Path,
    folds: Sequence[FoldDefinition],
    *,
    run_dir: Path,
) -> dict[int, FoldModel]:
    models: dict[int, FoldModel] = {}
    for fold in folds:
        root = run_dir / "cross-fitted-edge-models" / f"fold-{fold.index:02d}"
        model_path = root / "edge-model.json"
        summary_path = root / "fit-summary.json"
        evidence._run(
            [
                sys.executable,
                "-m",
                "raft_uav.multi_uav_lts.proposal_edge_model",
                proposal_dir,
                "--truth-dir",
                truth_dir,
                "--output-json",
                model_path,
                "--summary-json",
                summary_path,
                *_EDGE_MODEL_FIT_ARGUMENTS,
                "--sequences",
                *fold.training_sequences,
            ],
            log_path=root / "fit-console.txt",
        )
        models[fold.index] = _validate_model_provenance(
            model_path,
            summary_path,
            fold,
        )
    return models


def _selected_resolution_groups(
    groups: Sequence[tuple[tuple[int, int], tuple[str, ...]]],
    sequences: Sequence[str],
) -> tuple[tuple[tuple[int, int], tuple[str, ...]], ...]:
    selected = set(sequences)
    grouped: list[tuple[tuple[int, int], tuple[str, ...]]] = []
    covered: set[str] = set()
    for dimensions, group_sequences in groups:
        subset = tuple(sequence for sequence in group_sequences if sequence in selected)
        if subset:
            grouped.append((dimensions, subset))
            covered.update(subset)
    if covered != selected:
        missing = sorted(selected - covered)
        extra = sorted(covered - selected)
        raise ValueError(f"resolution groups mismatch: missing={missing}, extra={extra}")
    return tuple(grouped)


def _materialize_oof_candidate(
    name: str,
    arguments: Sequence[str],
    proposal_dir: Path,
    seed_dir: Path,
    folds: Sequence[FoldDefinition],
    models: Mapping[int, FoldModel],
    resolution_groups: Sequence[tuple[tuple[int, int], tuple[str, ...]]],
    *,
    run_dir: Path,
    expected_sequences: int,
) -> Path:
    root = run_dir / name
    output_dir = root / "predictions"
    shutil.rmtree(output_dir, ignore_errors=True)
    output_dir.mkdir(parents=True)
    copied_names: set[str] = set()
    fold_records: list[dict[str, Any]] = []

    for fold in folds:
        model = models.get(fold.index)
        if model is None or model.fold != fold:
            raise ValueError(f"missing or mismatched edge model for fold {fold.index}")
        resolved_arguments = _replace_edge_model_token(arguments, model.model_path)
        group_records: list[dict[str, Any]] = []
        for (width, height), sequences in _selected_resolution_groups(
            resolution_groups,
            fold.heldout_sequences,
        ):
            group_name = f"{width}x{height}"
            group_root = root / "folds" / f"fold-{fold.index:02d}" / group_name
            group_output = group_root / "predictions"
            shutil.rmtree(group_output, ignore_errors=True)
            evidence._run(
                [
                    sys.executable,
                    "-m",
                    "raft_uav.multi_uav_lts.experimental_proposal_graph_tracker",
                    proposal_dir,
                    "--first-frame-label-dir",
                    seed_dir,
                    "--output-dir",
                    group_output,
                    "--output-json",
                    group_root / "summary.json",
                    "--image-width",
                    str(width),
                    "--image-height",
                    str(height),
                    *resolved_arguments,
                    "--sequences",
                    *sequences,
                ],
                log_path=group_root / "console.txt",
            )
            _digest, total_bytes, count = evidence._directory_digest(group_output)
            if count != len(sequences):
                raise ValueError(
                    f"{name}/fold-{fold.index:02d}/{group_name} covers {count} "
                    f"sequences, expected {len(sequences)}"
                )
            if total_bytes <= 0:
                raise ValueError(
                    f"{name}/fold-{fold.index:02d}/{group_name} produced no rows"
                )
            for source in sorted(group_output.glob("*.txt")):
                if source.name in copied_names:
                    raise ValueError(f"{name}: duplicate held-out prediction {source.name}")
                shutil.copy2(source, output_dir / source.name)
                copied_names.add(source.name)
            group_records.append(
                {
                    "width": width,
                    "height": height,
                    "sequences": list(sequences),
                    "prediction_content_bytes": total_bytes,
                }
            )
        fold_records.append(
            {
                "fold": fold.index,
                "training_sequences": list(fold.training_sequences),
                "heldout_sequences": list(fold.heldout_sequences),
                "edge_model_path": str(model.model_path),
                "edge_model_sha256": model.model_sha256,
                "training_examples": model.training_examples,
                "positive_candidate_edges": model.positive_candidate_edges,
                "negative_candidate_edges": model.negative_candidate_edges,
                "resolution_groups": group_records,
            }
        )

    digest, total_bytes, count = evidence._directory_digest(output_dir)
    expected_names = {f"{sequence}.txt" for fold in folds for sequence in fold.heldout_sequences}
    if copied_names != expected_names:
        missing = sorted(expected_names - copied_names)
        extra = sorted(copied_names - expected_names)
        raise ValueError(f"{name} OOF coverage mismatch: missing={missing}, extra={extra}")
    if count != expected_sequences:
        raise ValueError(f"{name} covers {count} sequences, expected {expected_sequences}")
    if total_bytes <= 0:
        raise ValueError(f"{name} produced no prediction rows")
    evidence._write_json(
        root / "cross-fitted-summary.json",
        {
            "schema": "raft-uav-multi-uav-lts-cross-fitted-edge-candidate-v1",
            "candidate": name,
            "fold_count": len(folds),
            "fold_seed": FOLD_SEED,
            "candidate_arguments_template": list(arguments),
            "prediction_file_count": count,
            "prediction_content_bytes": total_bytes,
            "prediction_content_sha256": digest,
            "folds": fold_records,
            "leakage_guard": (
                "Each held-out sequence was tracked by an edge model trained only on "
                "the complementary folds. Truth was used only during model fitting."
            ),
        },
    )
    return output_dir


def _run_cross_fitted_candidates(
    proposal_dir: Path,
    seed_dir: Path,
    *,
    truth_dir: Path,
    image_root: Path,
    run_dir: Path,
    expected_sequences: int,
) -> dict[str, Path]:
    sequences = _sequence_manifest(seed_dir, expected_sequences=expected_sequences)
    folds = _build_fold_definitions(sequences)
    resolution_groups = improved._sequence_resolution_groups(image_root, seed_dir)
    evidence._write_json(
        run_dir / "cross-fitted-edge-folds.json",
        {
            "schema": "raft-uav-multi-uav-lts-cross-fitted-edge-folds-v1",
            "fold_count": FOLD_COUNT,
            "fold_seed": FOLD_SEED,
            "sequence_count": len(sequences),
            "folds": [
                {
                    "fold": fold.index,
                    "training_sequences": list(fold.training_sequences),
                    "heldout_sequences": list(fold.heldout_sequences),
                }
                for fold in folds
            ],
        },
    )
    models = _fit_fold_models(proposal_dir, truth_dir, folds, run_dir=run_dir)
    outputs: dict[str, Path] = {}
    for name, arguments in CROSS_FITTED_CANDIDATES:
        outputs[name] = _materialize_oof_candidate(
            name,
            arguments,
            proposal_dir,
            seed_dir,
            folds,
            models,
            resolution_groups,
            run_dir=run_dir,
            expected_sequences=expected_sequences,
        )
    return outputs


def _extend_available_results(
    original,
    run_dir: Path,
) -> dict[str, Any]:
    results = original(run_dir)
    metrics = results.setdefault("metrics", {})
    for name, _arguments in CROSS_FITTED_CANDIDATES:
        path = run_dir / name / "metrics.json"
        if not path.is_file() or name in metrics:
            continue
        try:
            metrics[name] = _load_json_object(path)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            metrics[name] = {"read_error": f"{type(exc).__name__}: {exc}"}
    return results


def main() -> int:
    evidence.CANDIDATES = ()
    improved.IMPROVED_CANDIDATES = STATIC_CANDIDATES
    if any(argument in {"-h", "--help"} for argument in sys.argv[1:]):
        return improved.main()

    truth_dir = _dataset_path_from_inputs(sys.argv[1:], "truth_dir")
    image_root = _dataset_path_from_inputs(sys.argv[1:], "train_sequence_root")
    original_runner = improved._run_candidates_with_native_dimensions
    original_available_results = evidence._available_results

    def run_candidates(
        proposal_dir: Path,
        seed_dir: Path,
        *,
        image_root: Path,
        run_dir: Path,
        expected_sequences: int,
    ) -> dict[str, Path]:
        static_outputs = original_runner(
            proposal_dir,
            seed_dir,
            image_root=image_root,
            run_dir=run_dir,
            expected_sequences=expected_sequences,
        )
        cross_fitted_outputs = _run_cross_fitted_candidates(
            proposal_dir,
            seed_dir,
            truth_dir=truth_dir,
            image_root=image_root,
            run_dir=run_dir,
            expected_sequences=expected_sequences,
        )
        overlap = set(static_outputs) & set(cross_fitted_outputs)
        if overlap:
            raise ValueError(f"duplicate candidate names: {', '.join(sorted(overlap))}")
        return {**static_outputs, **cross_fitted_outputs}

    def available_results(run_dir: Path) -> dict[str, Any]:
        return _extend_available_results(original_available_results, run_dir)

    improved._run_candidates_with_native_dimensions = run_candidates
    evidence._available_results = available_results
    try:
        return improved.main()
    finally:
        improved._run_candidates_with_native_dimensions = original_runner
        evidence._available_results = original_available_results


if __name__ == "__main__":
    raise SystemExit(main())
