from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = ROOT / "scripts"
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))


def _load_script():
    path = SCRIPT_DIR / "run_multi_uav_lts_cross_fitted_edge_evidence.py"
    spec = importlib.util.spec_from_file_location("cross_fitted_edge_evidence", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


cross_fitted = _load_script()


def _write_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload), encoding="utf-8")


def _fold_model(tmp_path: Path, fold):
    root = tmp_path / f"model-{fold.index}"
    model_path = root / "edge-model.json"
    summary_path = root / "fit-summary.json"
    _write_json(
        model_path,
        {
            "schema": "raft-uav-multi-uav-lts-edge-likelihood-v1",
            "sequence_count": len(fold.training_sequences),
            "training_example_count": 12,
            "positive_example_count": 5,
            "negative_example_count": 7,
            "metadata": {"selected_sequences": list(fold.training_sequences)},
        },
    )
    _write_json(
        summary_path,
        {
            "schema": "raft-uav-multi-uav-lts-edge-model-fit-summary-v1",
            "selected_sequences": list(fold.training_sequences),
            "selected_sequence_count": len(fold.training_sequences),
            "training_examples": 12,
            "positive_candidate_edges": 5,
            "negative_candidate_edges": 7,
        },
    )
    return cross_fitted._validate_model_provenance(model_path, summary_path, fold)


def test_build_fold_definitions_is_complete_and_leakage_free() -> None:
    sequences = tuple(
        f"{scenario}_{index:02d}"
        for scenario in ("C", "T", "BB2P")
        for index in range(5)
    )

    folds = cross_fitted._build_fold_definitions(sequences, fold_count=5, seed=0)

    assert len(folds) == 5
    heldout = [sequence for fold in folds for sequence in fold.heldout_sequences]
    assert sorted(heldout) == sorted(sequences)
    assert len(heldout) == len(set(heldout))
    for fold in folds:
        assert set(fold.training_sequences).isdisjoint(fold.heldout_sequences)
        assert set(fold.training_sequences) | set(fold.heldout_sequences) == set(sequences)


def test_replace_edge_model_token_requires_exactly_one_placeholder(tmp_path: Path) -> None:
    model_path = tmp_path / "model.json"

    resolved = cross_fitted._replace_edge_model_token(
        ("--edge-model-json", cross_fitted._EDGE_MODEL_TOKEN, "--flag"),
        model_path,
    )

    assert resolved == ("--edge-model-json", str(model_path), "--flag")
    with pytest.raises(ValueError, match="exactly one"):
        cross_fitted._replace_edge_model_token(("--flag",), model_path)
    with pytest.raises(ValueError, match="exactly one"):
        cross_fitted._replace_edge_model_token(
            (cross_fitted._EDGE_MODEL_TOKEN, cross_fitted._EDGE_MODEL_TOKEN),
            model_path,
        )


def test_validate_model_provenance_rejects_heldout_training_leakage(
    tmp_path: Path,
) -> None:
    fold = cross_fitted.FoldDefinition(
        index=0,
        training_sequences=("C_01", "T_01"),
        heldout_sequences=("C_02",),
    )
    model = _fold_model(tmp_path, fold)

    assert model.fold == fold
    assert model.training_examples == 12
    payload = json.loads(model.model_path.read_text(encoding="utf-8"))
    payload["metadata"]["selected_sequences"] = ["C_01", "C_02"]
    _write_json(model.model_path, payload)

    with pytest.raises(ValueError, match="provenance"):
        cross_fitted._validate_model_provenance(
            model.model_path,
            model.summary_path,
            fold,
        )


def test_selected_resolution_groups_cover_only_requested_sequences() -> None:
    groups = (
        ((1920, 1080), ("C_01", "C_02")),
        ((1280, 720), ("T_01", "T_02")),
    )

    selected = cross_fitted._selected_resolution_groups(groups, ("C_02", "T_01"))

    assert selected == (
        ((1920, 1080), ("C_02",)),
        ((1280, 720), ("T_01",)),
    )
    with pytest.raises(ValueError, match="resolution groups mismatch"):
        cross_fitted._selected_resolution_groups(groups, ("missing",))


def test_materialized_candidate_uses_only_the_complement_model_for_each_fold(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    folds = (
        cross_fitted.FoldDefinition(
            index=0,
            training_sequences=("T_01", "T_02"),
            heldout_sequences=("C_01", "C_02"),
        ),
        cross_fitted.FoldDefinition(
            index=1,
            training_sequences=("C_01", "C_02"),
            heldout_sequences=("T_01", "T_02"),
        ),
    )
    models = {fold.index: _fold_model(tmp_path, fold) for fold in folds}
    resolution_groups = (
        ((1920, 1080), ("C_01", "T_01")),
        ((1280, 720), ("C_02", "T_02")),
    )
    calls: dict[str, str] = {}

    def fake_run(command, *, log_path, cwd=None, environment=None) -> None:
        del cwd, environment
        normalized = [str(value) for value in command]
        output_dir = Path(normalized[normalized.index("--output-dir") + 1])
        model_path = normalized[normalized.index("--edge-model-json") + 1]
        sequences = normalized[normalized.index("--sequences") + 1 :]
        output_dir.mkdir(parents=True, exist_ok=True)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text("ok\n", encoding="utf-8")
        for sequence in sequences:
            calls[sequence] = model_path
            (output_dir / f"{sequence}.txt").write_text(
                "1,1,0,0,10,10,1,1,1\n",
                encoding="utf-8",
            )

    monkeypatch.setattr(cross_fitted.evidence, "_run", fake_run)
    output = cross_fitted._materialize_oof_candidate(
        "graph_edge_oof",
        ("--edge-model-json", cross_fitted._EDGE_MODEL_TOKEN),
        tmp_path / "proposals",
        tmp_path / "seeds",
        folds,
        models,
        resolution_groups,
        run_dir=tmp_path / "run",
        expected_sequences=4,
    )

    assert sorted(path.stem for path in output.glob("*.txt")) == [
        "C_01",
        "C_02",
        "T_01",
        "T_02",
    ]
    assert calls["C_01"] == str(models[0].model_path)
    assert calls["C_02"] == str(models[0].model_path)
    assert calls["T_01"] == str(models[1].model_path)
    assert calls["T_02"] == str(models[1].model_path)
    summary = json.loads(
        (tmp_path / "run" / "graph_edge_oof" / "cross-fitted-summary.json").read_text(
            encoding="utf-8"
        )
    )
    assert summary["prediction_file_count"] == 4
    assert summary["fold_count"] == 2
