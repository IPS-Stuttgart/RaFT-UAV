# Cross-fitted learned-edge evidence for Multi-UAV LTS

## Purpose

The permissive proposal bank has substantially more diagnostic headroom than the
single-hypothesis tracker, but a learned association model can look deceptively strong when
it is fitted and scored on the same sequences. This experiment evaluates learned edge
likelihoods without that leakage.

The runner creates one complete prediction directory per candidate. For every sequence in
that directory, the edge model used at inference was trained only on the other four
scenario-stratified folds.

## Evidence contract

The runner uses the same deterministic fold construction as the guarded tournament:

- five folds;
- random seed zero;
- scenario-prefix stratification;
- every sequence held out exactly once.

For each fold it performs the following steps:

1. Fit the logistic same-identity edge model on the complementary four folds.
2. Verify that both the model metadata and fit summary list exactly those training
   sequences.
3. Reject any model whose training manifest intersects the held-out fold.
4. Run the proposal graph only on the held-out sequences.
5. Copy those predictions into the complete out-of-fold candidate directory.

Truth is consumed only by `proposal_edge_model` during training. The tracker subprocess
receives proposals, first-frame labels, the fitted model, native image dimensions, and the
held-out sequence names. It never receives the truth directory.

The generated `cross-fitted-summary.json` records the model digest, training sequence list,
held-out sequence list, edge counts, native-resolution groups, and final prediction digest
for every fold.

## Focused candidate ladder

The evidence run intentionally replaces the broad exploratory sweep with a compact,
predeclared ladder:

| Candidate | Learned edge model | Swarm-relative cost | Ambiguity beam | Motion model |
|---|---:|---:|---:|---|
| `graph_delayed_translation` | No | No | No | Translation |
| `graph_delayed_similarity` | No | No | No | Similarity |
| `graph_delayed_swarm` | No | Yes | No | Translation |
| `graph_edge_oof` | Out of fold | No | No | Translation |
| `graph_edge_swarm_oof` | Out of fold | Yes | No | Translation |
| `graph_edge_swarm_beam_oof` | Out of fold | Yes | Yes | Translation |

This ordering separates the value of delayed assignment, similarity compensation,
hand-designed local formation evidence, learned edge likelihoods, and ambiguity-component
reranking.

## Running the complete evidence job

The pull-request workflow automatically runs the complete 102-sequence tournament on the
self-hosted GPU runner for same-repository pull requests. It reuses the detector/proposal
cache because the cache key excludes association-only files.

A manual invocation uses the same workflow with:

- `expected_sequence_count=102`;
- `expected_frame_count=77293`;
- `require_improvement=true` for a merge gate.

The underlying command is:

```bash
python scripts/run_multi_uav_lts_cross_fitted_edge_evidence.py \
  --inputs-json /path/to/public-inputs.json \
  --run-dir /path/to/evidence-run \
  --device 0 \
  --expected-sequence-count 102 \
  --expected-frame-count 77293 \
  --require-improvement
```

## Acceptance boundary

A learned candidate is not accepted merely because its pooled training score is higher.
The existing guarded tournament still requires:

- complete prediction coverage;
- positive mean held-out Codabench HOTA gain;
- a non-negative paired-bootstrap HOTA lower bound;
- bounded MOTA and IDF1 regressions;
- bounded worst-scenario HOTA regression;
- deterministic fallback to the unmodified raw tracker.

The complete candidate is itself out of fold, so both the pooled result and the tournament
fold results are predictions from models that did not train on the scored sequence.

## Hidden-test use

The out-of-fold models are evaluation artifacts, not test-time models. If an edge candidate
passes the guard, fit one final edge model on all 102 training sequences and apply that model
to the hidden-test proposal bank with the exact selected tracker controls. Preserve the
training manifest, model digest, proposal-source digest, and selected candidate controls in
the submission provenance.

Do not combine fold-specific models on the hidden test and do not select a fold model based
on test sequence behavior.

## Failure interpretation

- If delayed translation wins but learned edges do not, the current feature model or its
  calibration is weak; do not add appearance complexity yet.
- If swarm-relative costs win, prioritize local formation and image-motion compensation.
- If learned edges win but the beam does not, use the learned model without reranking.
- If the beam wins only in a small scenario subset, retain it as a later expert rather than
  applying it globally.
- If every transformed candidate fails, keep raw and inspect per-sequence proposal-oracle
  headroom before changing the detector.
